package com.learn.springsecurity.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.learn.springsecurity.dto.response.BasicResponse;
import com.learn.springsecurity.dto.response.UserResponse;
import com.learn.springsecurity.enumerated.Role;
import com.learn.springsecurity.model.Users;
import com.learn.springsecurity.repository.UsersRepository;
import com.learn.springsecurity.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UsersRepository usersRepository;

    @Override
    public BasicResponse<UserResponse> getAllUser() {
        List<Users> users = usersRepository.findAll();
        List<UserResponse> userResponse = users.stream()
                .map(user -> UserResponse.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .password(user.getPassword())
                        .role(user.getRole())
                        .build())
                .collect(Collectors.toList());
        return BasicResponse.<UserResponse>builder().message("User data fetched successfully!").data(userResponse)
                .build();
    }

@Override
public UserResponse getprofile(String id) {
         var user = usersRepository.findById(id).orElseThrow();
        String userId = user.getId();
        String name = user.getName();
        String email = user.getEmail();
        Role userRole = user.getRole();
        return UserResponse.builder()
                .id(userId)
                .name(name)
                .email(email)
                .role(userRole)
                .build();
}

@Override
public long count() {
        return usersRepository.count();
}
}

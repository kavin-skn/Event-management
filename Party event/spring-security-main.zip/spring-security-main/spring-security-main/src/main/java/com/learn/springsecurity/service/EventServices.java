package com.learn.springsecurity.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.springsecurity.model.Events;
import com.learn.springsecurity.repository.EventRepo;

import java.util.List;
import java.util.Optional;

@Service
public class EventServices {
    @Autowired
    private EventRepo eventRepository;

    public List<Events> getAllEvents() {
        return eventRepository.findAll();
    }

    public Optional<Events> getEventById(int id) {
        return eventRepository.findById(id);
    }

    public Events saveEvent(Events event) {
        return eventRepository.save(event);
    }
}

package com.learn.springsecurity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.learn.springsecurity.model.Events;
import com.learn.springsecurity.service.EventServices;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("")
public class EventController {
    @Autowired
    private EventServices eventService;

    @GetMapping("/getEvents")
    public ResponseEntity<List<Events>> getAllEvents() {
        List<Events> events = eventService.getAllEvents();
        return ResponseEntity.ok(events);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Events> getEventById(@PathVariable int id) {
        Optional<Events> event = eventService.getEventById(id);
        return event.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/createEvent")
    public ResponseEntity<Events> createEvent(@RequestBody Events event) {
        Events createdEvent = eventService.saveEvent(event);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEvent);
    }
    public long countevent(){
        return 0;
    }
}
